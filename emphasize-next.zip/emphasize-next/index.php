<?php
include_once(dirname(__FILE__).'/includes/config.php');

if (strpos($domain, "://".$_SERVER['SERVER_NAME']) === false) {
  $redirect=true;
  if (isset($domains)) {
    foreach($domains as $l=>$d) {
      if (strpos($d, "://".$_SERVER['SERVER_NAME']) !== false) {
        $domain=$d;
        $redirect=false;
        break;
      }
    }
  }
  if ($redirect) {
	  $export="json";
	  header("Location: $domain"); /* Redirect browser */
	  exit();
	}
} else {
  if (isset($domains)) {
    $lang=detectLang();
    foreach($domains as $l=>$d) {
      if ($l==$lang) {
        $export="json";
	      header("Location: $d"); /* Redirect browser */
	      exit();
      }
    }
  }
}

if (!isset($_SESSION)) {
	session_start();
}
if (!empty($_POST)) {
	if (isset($_POST["do"]) && $_POST["do"] == "derefer") {
		$url = $_POST["url"];
		echo("<html><head><title>redirect</title><meta http-equiv=\"Refresh\" content=\"0; URL=$url\"><head><body bgcolor=\"#ffffff\" onLoad=\"javascript: window.location='$url';\"><center style=\"color:#aaaaaa;\">redirect to $url</center></body></html>");
		exit;
	} else if (isset($_POST["do"]) && $_POST["do"] == "createUser") {
		include_once(dirname(__FILE__).'/includes/registration.php');
	} else if (isset($_POST["do"]) && $_POST["do"] == "login") {
		$name = $_POST["name"];
		$pw_hash = pw_hash($_POST["password"]);
		$stay = $_POST["stay"];

		connectDb();
		login(true, $name, $pw_hash, $stay);
		if ($stay==0) {
			$export="json";
			header("Location: $domain?$token"); /* Redirect browser */
			exit;
		} else {
			include_once(dirname(__FILE__).'/includes/tabletti.php');
		}
	} else {
		include_once(dirname(__FILE__).'/includes/demo.php');
	}
} elseif (!empty($_GET)) {
	if ($_SERVER['QUERY_STRING']=="agb") {
		$lang=detectLang();
		checkCache("agb_".$lang.".html", "includes/agb.html", "includes/languages.php");
		include_once(dirname(__FILE__).'/includes/agb.html');
	} elseif (strlen($_SERVER['QUERY_STRING'])==20) {
		$token=$_SERVER['QUERY_STRING'];
		connectDb();
		
		pickup($token);
		include_once(dirname(__FILE__).'/includes/tabletti.php');
	} elseif (isset($_GET["lang"]) && strlen($_GET['lang'])==2) {
		if (isset($_SESSION['token'])) {
			$token=$_SESSION['token'];
			connectDb();
			pickup($token);
			setUserLang($_GET['lang']);
			include_once(dirname(__FILE__).'/includes/tabletti.php');
		} else {
			include_once(dirname(__FILE__).'/includes/demo.php');
		}
	} else if (isset($_GET["bid"]) && !empty($_GET["bid"])) {
		$bid=$_GET["bid"];
		include_once(dirname(__FILE__).'/includes/demo.php');
	}
} elseif (isset($_SESSION['token'])) {
	$token=$_SESSION['token'];
	connectDb();
	pickup($token);
	include_once(dirname(__FILE__).'/includes/tabletti.php');
} else {
	// correct includes filepermissions
	if (substr(decoct(fileperms('includes') ), 1) != "0700") {
		chmod('includes', 0700);
	}
	include_once(dirname(__FILE__).'/includes/demo.php');
}
bottom();
?>
